<?php

class config  
{	
	function __construct() {
		$this->host = "localhost";
		$this->user  = "root";
		$this->pass = "welcome";
		$this->db = "mydb13";
	}
}

?>